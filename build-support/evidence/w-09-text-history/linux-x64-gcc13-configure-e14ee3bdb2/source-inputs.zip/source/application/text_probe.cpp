#include "native_text.hpp"
#include <fstream>
#include <iostream>

namespace {
using syspane::configuration::Json;
Json rect(syspane::scene::Rect r){return Json::array({r.x,r.y,r.width,r.height});}
}
int main(int argc,char** argv){
    if(argc!=2)return 2;
    try{
        std::string bytes;char c;
        while(std::cin.get(c)){
            if(bytes.size()>=32768)throw syspane::protocol::Error("text.input");
            bytes.push_back(c);
        }
        const auto j=Json::parse(bytes);
        syspane::rendering::TextRequest r;
        r.text=j.at("text");r.theme=j.at("theme");
        r.language=j.value("language",r.language);r.token=j.value("token",r.token);r.contrast=j.value("contrast",r.contrast);
        r.numerator=j.value("numerator",r.numerator);r.denominator=j.value("denominator",r.denominator);
        r.pixel_budget=j.value("pixel_budget",r.pixel_budget);
        if(j.contains("wrap_units"))r.wrap_units=j.at("wrap_units").get<syspane::scene::Unit>();
        const auto original=r.theme;
        const auto a=syspane::rendering::render_text(r);
        std::ofstream f(argv[1],std::ios::binary);
        f.write(reinterpret_cast<const char*>(a.rgba.data()),static_cast<std::streamsize>(a.rgba.size()));
        f.close();if(!f)throw syspane::protocol::Error("probe.output");
        std::cout<<Json({{"ink",rect(a.ink)},{"logical",rect(a.logical)},{"extent",rect(a.extent)},
            {"preferred",Json::array({a.preferred.width,a.preferred.height})},{"baseline",a.baseline},
            {"lines",a.lines},{"missing_glyphs",a.missing_glyphs},{"fonts",a.fonts},{"width",a.width},
            {"height",a.height},{"theme_unchanged",r.theme==original}}).dump()<<'\n';
    }catch(const syspane::protocol::Error& e){std::cout<<Json({{"error",e.what()}}).dump()<<'\n';}
    catch(const std::exception&){std::cout<<"{\"error\":\"text.input\"}\n";}
}
