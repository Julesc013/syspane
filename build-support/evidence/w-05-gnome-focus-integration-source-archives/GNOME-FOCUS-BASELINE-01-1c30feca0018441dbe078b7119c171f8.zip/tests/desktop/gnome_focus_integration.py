"""Observe optional event-bound focus integration using native acceptance evidence."""
import ast
import json
import subprocess


def trace(environment):
    command = ['/usr/bin/gdbus','call','--address',environment['DBUS_SESSION_BUS_ADDRESS'],
               '--dest','org.gnome.Shell','--object-path','/org/syspane/LabMarker',
               '--method','org.syspane.LabMarker.GetFocusTrace']
    result = subprocess.run(command,env=environment,capture_output=True,text=True,timeout=1,check=True)
    if len(result.stdout)>70000 or result.stderr:raise ValueError('bounded focus trace required')
    value = ast.literal_eval(result.stdout)
    if not isinstance(value,tuple) or len(value)!=1 or not isinstance(value[0],str):raise ValueError('focus trace reply shape')
    return json.loads(value[0])


def observe(display,environment,workspace,baseline):
    return {'version':'0.1.0','mode':environment['SYSPANE_GNOME_FOCUS_INTEGRATION'],
            'initial_trace':trace(environment),'not_run':['native input/abstention/disable guards'],
            'outcome':'inconclusive'}
