#include "chart_fixture.hpp"
#include <iostream>
using namespace fixture;
int chart_surface_tests(const std::string& root){unsigned count=0;const auto test=[&](const char* name,const std::function<void()>& run){run();++count;std::cout<<name<<" pass\n";};
    test("BURST",[&]{ChartOwner f(root);f.full(10,0);f.full(90,500000000);f.full(10,1000000000);auto frame=f.paint();const auto& w=frame.widgets[0];
        need(w.chart&&w.chart->samples==3&&w.chart->segments==1,"retain every prepaint delivery");
        need(w.text=="Receive\n10 byte\nCurrent\nSamples 3 | Segments 1\nRange 0.0 .. 100.0 byte\nWindow 1000 ms | linear","visible chart summary");
        need(w.accessible.find("Point 500000000: 90; generation 2; join")!=std::string::npos,"accessible exact point");need(w.chart->pixels.width==320&&w.chart->pixels.height==120,"graph dimensions");
        need(f.paint().widgets[0].chart->samples==3,"paint cannot duplicate");});
    test("GAP",[&]{ChartOwner f(root);f.full(10,0);f.surface->gap("P1",f.token,7,++f.now);f.full(90,500000000);auto w=f.paint().widgets[0];
        need(w.chart->samples==2&&w.chart->segments==2,"gap cannot join");need(w.accessible.find("Point 500000000: 90; generation 2; start")!=std::string::npos,"gap accessible");});
    test("REATTACH",[&]{ChartOwner f(root);f.full(10,0);const auto old=f.token;f.attach();f.full(90,500000000);
        need(f.surface->disconnect("P1",old,7,++f.now)==r::DataCode::stale_attachment,"old disconnect");f.full(80,1000000000);
        auto w=f.paint().widgets[0];need(w.chart->samples==2&&w.chart->segments==1,"old callback cannot break successor");});
    test("HISTORY-POLICY",[&]{ChartOwner f(root);f.full(10,0);f.paint();auto p=chart_policy(8);p.disclosure.erase({"desktop","history"});f.surface->policy(p,++f.now);f.empty(v::SurfaceCode::restricted);
        f.surface->policy(chart_policy(9),++f.now);f.revision=9;auto w=f.paint().widgets[0];need(w.chart->samples==0&&w.text.find("Waiting")!=std::string::npos,"history grant no old data");
        f.attach();f.full(90,500000000);need(f.paint().widgets[0].chart->samples==1,"history fresh attach");});
    test("RESOURCE",[&]{ChartOwner f(root);f.full(10,0);f.paint();auto p=chart_policy(8);p.denied_capabilities.insert("scene.content");f.surface->policy(p,++f.now);f.empty(v::SurfaceCode::restricted);
        f.surface->policy(chart_policy(9),++f.now);f.revision=9;need(f.paint().widgets[0].chart->samples==0,"resource regrant cleared");});
    test("EXPIRY",[&]{ChartOwner f(root);f.full(10,0);f.now+=10000;need(f.surface->heartbeat("P1",f.token,7,1,++f.now)==r::DataCode::closed,"expired attachment stays closed");
        auto w=f.paint().widgets[0];need(w.chart->samples==1&&w.text.find("Retained")!=std::string::npos&&w.text.find("Gap pending")!=std::string::npos,"expiry remains explicit");
        f.attach();f.full(90,500000000);need(f.paint().widgets[0].chart->samples==1,"fresh attachment resets expired history");});
    test("WINDOW",[&]{ChartOwner f(root);f.full(10,0);f.full(20,500000000);f.full(30,1500000001);need(f.paint().widgets[0].chart->samples==1,"window drops expired points");});
    test("REPLACE",[&]{ChartOwner f(root);f.full(10,0);f.full(20,500000000);auto cfg=f.cfg;cfg.authored.scene["widgets"][0]["content"]["interpolation"]="step";f.surface->replace(cfg,++f.now);
        auto w=f.paint().widgets[0];need(w.chart->samples==1&&w.text.find("| step")!=std::string::npos,"replacement resets history");});
    test("CLEAR-FAILURE",[&]{ChartOwner f(root);f.full(10,0);f.paint();f.clear_ok=false;f.surface->policy(chart_policy(8,false),++f.now);f.empty(v::SurfaceCode::closed);});
    test("BUDGET",[&]{ChartOwner f(root);auto cfg=f.cfg;auto prototype=cfg.authored.scene["widgets"][0];cfg.authored.scene["widgets"]=Json::array();cfg.authored.scene["roots"]=Json::array();
        for(unsigned i=0;i<5;++i){auto w=prototype;w["id"]="chart:"+std::to_string(i);w["content"]["max_points"]=4096;cfg.authored.scene["widgets"].push_back(w);cfg.authored.scene["roots"].push_back(w["id"]);}
        f.surface->replace(cfg,++f.now);f.empty(v::SurfaceCode::alternative);need(f.surface->status().reason=="surface.capacity","aggregate history reservation");});
    test("DISCONNECT",[&]{ChartOwner f(root);f.full(10,0);f.full(90,500000000);f.surface->disconnect("P1",f.token,7,++f.now);auto w=f.paint().widgets[0];
        need(w.chart->samples==2&&w.text.find("Retained")!=std::string::npos&&w.text.find("Gap pending")!=std::string::npos,"retained history explicit");});
    std::cout<<"CHART-SURFACE-FAMILIES "<<count<<'\n';return 0;
}
