#pragma once
#include "transaction.hpp"
#include <memory>

namespace syspane::platform {
// Explicit private development store. Native ext4 only; no installed location.
class LinuxGenerationStore final:public configuration::GenerationStore {
public:
    explicit LinuxGenerationStore(const std::string& directory,std::function<void(const char*)> transition={});
    ~LinuxGenerationStore()override;
    LinuxGenerationStore(const LinuxGenerationStore&)=delete;
    LinuxGenerationStore& operator=(const LinuxGenerationStore&)=delete;
    void initialize(const configuration::Authored& documents);
    configuration::Committed load()const override;
    std::optional<configuration::Committed> reconcile(const std::string&,const std::string&,const std::string&)const override;
    configuration::Publication publish(const configuration::Committed&,const std::function<void()>&)override;
    bool recovered_previous()const;
private:
    struct Impl;std::unique_ptr<Impl> impl_;
};
}
