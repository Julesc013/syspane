"""Native GNOME application-list observations over a private read-only AT-SPI bus."""
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import select
import subprocess
import time

from native_oracle import ROOT
from native_x11_host import rgb_record
from x11_recovery import ResourceOwner
from gnome_composition import FIXTURE as SCENE, settings, judge_samples

FIXTURE_PATH = ROOT/'tests/desktop/fixtures/gnome-switcher.json'
FIXTURE = json.loads(FIXTURE_PATH.read_text())


def prepare(workspace):
    apps = workspace/'data/applications'; apps.mkdir()
    icons = workspace/'data/icons'; icons.mkdir(exist_ok=True)
    records = {}
    for role, item in FIXTURE['applications'].items():
        icon = icons/(item['id']+'.svg')
        color = ','.join(map(str, item['icon_rgb']))
        icon.write_text('<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><rect width="64" height="64" fill="rgb('+color+')"/></svg>\n')
        text = ('[Desktop Entry]\nType=Application\nName='+item['name']+'\nExec=/usr/bin/python3 '+
                str(ROOT/'tests/desktop/gnome_switcher_app.py')+' '+role+'\nIcon='+str(icon)+
                '\nStartupWMClass='+item['id']+'\nTerminal=false\nDBusActivatable=false\n')
        (apps/(item['id']+'.desktop')).write_text(text)
        records[role] = {'desktop': text, 'icon': icon.read_text()}
    return records


def native_settings(environment):
    values = {}
    for schema, key in [('org.gnome.shell', 'favorite-apps'), ('org.gnome.desktop.wm.keybindings', 'switch-applications')]:
        value = subprocess.run(['/usr/bin/gsettings', 'get', schema, key], env=environment,
                               capture_output=True, text=True, timeout=1, check=True)
        if value.stderr or len(value.stdout)>512: raise ValueError('native switcher settings response')
        values[key] = value.stdout.strip()
    return values


def identity(display, pid, role):
    matches = []
    for window in display.property(display.root, '_NET_CLIENT_LIST_STACKING'):
        owner = ResourceOwner(display).pid(window)
        if not owner or owner[0]!=pid: continue
        kind = display.property(window, '_NET_WM_WINDOW_TYPE')
        if kind!=[display.atom('_NET_WM_WINDOW_TYPE_NORMAL')]: raise ValueError('normal fixture window required')
        x, y, child = C.c_int(), C.c_int(), C.c_ulong()
        if not display.x.XTranslateCoordinates(display.handle, window, display.root, 0, 0, C.byref(x), C.byref(y), C.byref(child)):
            raise ValueError('fixture client coordinates unavailable')
        path = Path('/proc')/str(pid)
        arguments = [p.decode() for p in (path/'cmdline').read_bytes().rstrip(b'\0').split(b'\0')]
        state = (path/'stat').read_text().rsplit(')',1)[1].split()
        if arguments!=['/usr/bin/python3',str(ROOT/'tests/desktop/gnome_switcher_app.py'),role] or int(state[2])!=pid or int(state[3])!=pid:
            raise ValueError('owned application process identity')
        if [x.value,y.value]!=FIXTURE['applications'][role]['window'][:2]: raise ValueError('fixture geometry differs')
        matches.append({'window':window,'pid':pid,'role':role,'resource_base':owner[1],'resource_mask':owner[2],
                        'arguments':arguments,'process_group':int(state[2]),'session':int(state[3]),'start_ticks':int(state[19]),
                        'executable':str((path/'exe').resolve(strict=True)),'origin':[x.value,y.value],'type':kind})
    if len(matches)!=1: raise ValueError('one owned application window required')
    return matches[0]


class ShellObserver:
    def __init__(self, display, environment, workspace, shell_pid):
        from gi.repository import Gio, GLib
        self.api,self.glib = Gio,GLib
        self.bus = Gio.DBusConnection.new_for_address_sync(environment['AT_SPI_BUS_ADDRESS'],
            Gio.DBusConnectionFlags.AUTHENTICATION_CLIENT|Gio.DBusConnectionFlags.MESSAGE_BUS_CONNECTION,None,None)
        self.display,self.shell_pid = display,shell_pid
        self.journal = (workspace/'switcher.jsonl').open('x',encoding='utf-8',newline='\n')
        self.count = 0
        display.xtest.XTestFakeMotionEvent.argtypes = [C.c_void_p,C.c_int,C.c_int,C.c_int,C.c_ulong]
        display.xtest.XTestFakeButtonEvent.argtypes = [C.c_void_p,C.c_uint,C.c_int,C.c_ulong]

    def preserve(self,kind,value):
        self.count+=1
        if self.count>180: raise ValueError('switcher journal record capacity')
        self.journal.write(json.dumps({'kind':kind,'value':value},separators=(',',':'))+'\n');self.journal.flush()
        if self.journal.tell()>8*1024**2: raise ValueError('switcher journal byte capacity')

    def key(self,name,pressed):
        d=self.display;code=d.x.XKeysymToKeycode(d.handle,d.x.XStringToKeysym(name.encode()))
        if not code or not d.xtest.XTestFakeKeyEvent(d.handle,code,pressed,0):raise ValueError('native key stimulus failed')
        d.x.XFlush(d.handle)
        self.preserve('key',{'name':name,'pressed':pressed,'at_ns':time.monotonic_ns()})

    def tap(self,name):self.key(name,True);self.key(name,False)

    def click(self,role):
        x,y,w,h=FIXTURE['applications'][role]['window'];d=self.display
        if not d.xtest.XTestFakeMotionEvent(d.handle,-1,x+w//2,y+h//2,0):raise ValueError('fixture pointer motion')
        for down in (True,False):
            if not d.xtest.XTestFakeButtonEvent(d.handle,1,down,0):raise ValueError('fixture click')
        d.x.XFlush(d.handle);self.preserve('click',{'role':role,'point':[x+w//2,y+h//2],'at_ns':time.monotonic_ns()})

    def tree(self):
        started=time.monotonic_ns();deadline=time.monotonic()+3
        def call(destination,path,interface,method,args=None):
            if time.monotonic()>=deadline:raise TimeoutError('shell tree deadline')
            return self.bus.call_sync(destination,path,interface,method,args,None,self.api.DBusCallFlags.NO_AUTO_START,250,None).unpack()
        accessible='org.a11y.atspi.Accessible'
        children=call('org.a11y.atspi.Registry','/org/a11y/atspi/accessible/root',accessible,'GetChildren')[0]
        if len(children)>8:raise ValueError('private application capacity')
        apps=[]
        for app in children:
            pid=call('org.freedesktop.DBus','/org/freedesktop/DBus','org.freedesktop.DBus','GetConnectionUnixProcessID',self.glib.Variant('(s)',(app[0],)))[0]
            if pid==self.shell_pid:apps.append(app)
        if len(apps)!=1:raise ValueError('unique native shell accessibility peer required: '+str(children))
        rows=[];queue=[(apps[0],[],0)]
        while queue:
            if len(rows)>=512:raise ValueError('shell tree node capacity')
            obj,path,depth=queue.pop(0)
            if depth>24:raise ValueError('shell tree depth capacity')
            destination,object_path=obj
            if destination!=apps[0][0]:raise ValueError('foreign shell subtree peer')
            name=call(destination,object_path,'org.freedesktop.DBus.Properties','Get',self.glib.Variant('(ss)',(accessible,'Name')))[0] or ''
            if len(name)>256:raise ValueError('shell tree name capacity')
            states=call(destination,object_path,accessible,'GetState')[0]
            if len(states)!=2:raise ValueError('shell tree state shape')
            role=call(destination,object_path,accessible,'GetRoleName')[0]
            interfaces=call(destination,object_path,accessible,'GetInterfaces')[0]
            rectangle=None
            if 'org.a11y.atspi.Component' in interfaces:
                rectangle=list(call(destination,object_path,'org.a11y.atspi.Component','GetExtents',self.glib.Variant('(u)',(0,)))[0])
            rows.append({'path':path,'name':name,'role':role,'states':list(states),'showing':bool(states[0]&(1<<25)),
                         'selected':bool(states[0]&(1<<23)),'rectangle':rectangle,
                         'bus_name':destination,'object_path':object_path,'native_bus_pid':self.shell_pid})
            children=call(destination,object_path,accessible,'GetChildren')[0]
            if len(children)>64:raise ValueError('shell tree child capacity')
            queue.extend((child,path+[n],depth+1) for n,child in enumerate(children))
        return {'started_ns':started,'finished_ns':time.monotonic_ns(),'rows':rows,'bus_name':apps[0][0],'native_bus_pid':self.shell_pid}

    def capture(self,step):
        started=time.monotonic_ns();tree=self.tree()
        row={'step':step,'started_ns':started,'tree':tree,'pixels':rgb_record(self.display.capture(0,0,800,600)),
             'native':self.display.structure(),'finished_ns':time.monotonic_ns()}
        self.preserve('observation',row);return row

    def close(self):self.bus.close_sync(None);self.journal.close()


def observe(display,environment,shell_pid,workspace,composition,trace_function):
    observer=ShellObserver(display,environment,workspace,shell_pid)
    pids=json.loads(environment['SYSPANE_GNOME_SWITCHER_PIDS']);descriptors=[]
    result={'version':'0.1.0','control':environment['SYSPANE_GNOME_SWITCHER_CONTROL'],
            'fixture_sha256':hashlib.sha256(FIXTURE_PATH.read_bytes()).hexdigest(),
            'applications':{},'observations':[],'settings_before':native_settings(environment)}
    try:
        if composition['outcome']!='pass':raise ValueError('live composition prerequisite')
        for role,pid in pids.items():
            descriptors.append(os.pidfd_open(pid));result['applications'][role]=identity(display,pid,role)
        observer.preserve('identity',result)
        observer.click('beta');time.sleep(.1);observer.click('alpha');time.sleep(.2)
        result['observations'].append(observer.capture('baseline'))
        if result['control']!='no-switcher':
            observer.key('Alt_L',True);observer.tap('Tab')
        time.sleep(.5)
        result['observations'].append(observer.capture('switcher'))
        observer.tap('Escape');observer.key('Alt_L',False);time.sleep(.2)
        result['observations'].append(observer.capture('cancelled'))
        for role in ['beta','alpha']:
            observer.key('Alt_L',True);observer.tap('Tab');observer.key('Alt_L',False);time.sleep(.2)
            result['observations'].append(observer.capture('selected-'+role))
        observer.tap('Super_L');time.sleep(.5)
        result['observations'].append(observer.capture('overview'))
        observer.tap('Escape');time.sleep(.2)
        result['observations'].append(observer.capture('restored'))
        result['settings_after']=native_settings(environment)
        result['outcome']='inconclusive'
        result['reason']='Native shell application-list observation requires calibration against the positive controls.'
        observer.preserve('completed',result)
        return result
    except Exception as error:
        observer.preserve('error',{'message':type(error).__name__+': '+str(error)})
        raise
    finally:
        for descriptor in descriptors:os.close(descriptor)
        observer.close()
