"""Bounded GNOME bootstrap on an authenticated owned Xvfb display, never a user session."""
import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import multiprocessing as mp
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import uuid
import zipfile

from native_oracle import Display, ROOT, launch_xvfb
from native_x11_host import rgb_record
from x11_recovery import ResourceOwner, manager_identity

sys.path.insert(0, str(ROOT / 'build-support'))
from prepare_gnome_lab import owned_build, sha, inventory

SOURCES = ['tests/desktop/native_gnome_bootstrap.py', 'tests/desktop/native_oracle.py',
           'tests/desktop/native_x11_host.py', 'tests/desktop/x11_recovery.py',
           'tests/desktop/oracle.py', 'tests/fault/native_diagnostic.py',
           'build-support/prepare_gnome_lab.py', 'build-support/gnome-lab-packages.json',
           'spec/delivery/packages/w-05-gnome-investigation.md']


def observe(environment, pid, channel):
    os.environ.clear()
    os.environ.update(environment)
    display = None
    try:
        display = Display()
        owner = ResourceOwner(display)
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            manager = manager_identity(display, owner)
            if manager and manager['pid'] == [pid] and manager['self'] == [manager['window']]:
                break
            time.sleep(.05)
        else:
            raise TimeoutError('owned GNOME manager resource did not become ready')
        frames = []
        # A native WM resource alone can precede a fatal shell JS startup error.
        for delay in (0, 1, 4):
            time.sleep(delay)
            started = time.monotonic_ns()
            rgb = display.capture(0, 0, 800, 600)
            frames.append({'capture_started_ns': started, 'capture_finished_ns': time.monotonic_ns(),
                           'origin': 'display_server_root', 'pixels': rgb_record(rgb)})
            if manager_identity(display, owner) != manager:
                raise ValueError('manager disappeared or changed during bootstrap interval')
        channel.send({'outcome': 'pass', 'manager': manager, 'frames': frames})
    except Exception as error:
        channel.send({'outcome': 'fail', 'error': type(error).__name__ + ': ' + str(error)})
    finally:
        if display:
            display.close()
        channel.close()


def mapped_files(pid):
    paths = set()
    for row in Path(f'/proc/{pid}/maps').read_text().splitlines():
        fields = row.split(maxsplit=5)
        if len(fields) == 6 and fields[5].startswith('/'):
            paths.add(fields[5])
    return {p: sha(Path(p)) for p in sorted(paths) if Path(p).is_file()}


def group_members(group):
    members = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == group and int(fields[3]) == group:
                members.append({'pid': int(path.name), 'state': fields[0]})
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    return members


def run(build):
    # Retain orphaned shell helpers for reaping; no service/session can adopt them.
    if ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), 'cannot retain descendant exit evidence')
    lab = build / 'gnome-lab'
    sysroot = lab / 'sysroot'
    identity = json.loads((lab / 'identity.json').read_text())
    if identity['lock_sha256'] != sha(ROOT / 'build-support/gnome-lab-packages.json') or identity['files'] != inventory(sysroot):
        raise ValueError('pinned GNOME runtime identity changed')
    evidence = build / 'native-evidence'
    evidence.mkdir(exist_ok=True)
    token = 'GNOME-BOOTSTRAP-01-' + uuid.uuid4().hex
    workspace = build / token
    workspace.mkdir(mode=0o700)
    for name in ('home', 'config', 'data', 'cache', 'run', 'schemas'):
        (workspace / name).mkdir(mode=0o700)
    # Mutter's documented uninstalled-test fallback is relative to its CWD.
    # Resolve it to the exact extracted helper without changing /usr/libexec.
    # GNOME Shell changes CWD to its isolated HOME before initializing Mutter.
    (workspace / 'home/src/frames').mkdir(parents=True)
    (workspace / 'home/src/frames/mutter-x11-frames').symlink_to(sysroot / 'usr/libexec/mutter-x11-frames')
    report = {'family': 'GNOME-BOOTSTRAP-01', 'outcome': 'fail',
              'executed_at': datetime.now(timezone.utc).isoformat(),
              'source_base': subprocess.check_output(['git', '-c', 'safe.directory=' + str(ROOT), 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
              'source_inputs': {p: sha(ROOT / p) for p in SOURCES},
              'workspace': str(workspace), 'lab_identity_sha256': sha(lab / 'identity.json'),
              'environment': {'uid': os.geteuid(), 'os_release_sha256': sha(Path('/etc/os-release'))},
              'system_binaries': {p: sha(Path(p)) for p in ['/usr/bin/Xvfb', '/usr/bin/dbus-daemon', '/usr/bin/glib-compile-schemas', '/usr/lib/x86_64-linux-gnu/libXRes.so.1']},
              'commands': [], 'cleanup': [],
              'qualification': 'Laboratory bootstrap only; placement, reveal, icons, input, recovery, Wayland and product host qualification are not run.'}
    archive = workspace / 'source-inputs.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as target:
        for name in SOURCES:
            target.write(ROOT / name, name)
    report['source_archive'] = {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive)}
    server = worker = None
    children, streams = [], []
    started = time.monotonic()
    try:
        server, inherited = launch_xvfb(workspace)
        bus = 'unix:abstract=syspane-gnome-' + uuid.uuid4().hex
        environment = {'PATH': str(sysroot / 'usr/bin') + ':/usr/bin:/bin', 'LC_ALL': 'C.UTF-8',
                       'HOME': str(workspace / 'home'), 'USER': 'ir4runner',
                       'DISPLAY': inherited['DISPLAY'], 'XAUTHORITY': inherited['XAUTHORITY'],
                       'XDG_CONFIG_HOME': str(workspace / 'config'), 'XDG_DATA_HOME': str(workspace / 'data'),
                       'XDG_CACHE_HOME': str(workspace / 'cache'), 'XDG_RUNTIME_DIR': str(workspace / 'run'),
                       'XDG_CONFIG_DIRS': str(sysroot / 'etc/xdg'),
                       'XDG_DATA_DIRS': str(sysroot / 'usr/share') + ':/usr/share',
                       'XDG_CURRENT_DESKTOP': 'GNOME', 'XDG_SESSION_TYPE': 'x11',
                       'DBUS_SESSION_BUS_ADDRESS': bus, 'DBUS_SYSTEM_BUS_ADDRESS': 'unix:path=' + str(workspace / 'run/no-system-bus'),
                       'AT_SPI_BUS_ADDRESS': bus, 'NO_AT_BRIDGE': '1',
                       'GIO_USE_VFS': 'local', 'GSETTINGS_BACKEND': 'keyfile',
                       'GSETTINGS_SCHEMA_DIR': str(workspace / 'schemas'),
                       'GTK_USE_PORTAL': '0', 'GDK_BACKEND': 'x11', 'LIBGL_ALWAYS_SOFTWARE': '1',
                       'LD_LIBRARY_PATH': ':'.join(str(sysroot / p) for p in ('usr/lib/gnome-shell', 'usr/lib/x86_64-linux-gnu/mutter-14', 'usr/lib/x86_64-linux-gnu')),
                       'GI_TYPELIB_PATH': ':'.join(str(sysroot / p) for p in ('usr/lib/gnome-shell', 'usr/lib/x86_64-linux-gnu/mutter-14', 'usr/lib/x86_64-linux-gnu/gjs/girepository-1.0', 'usr/lib/x86_64-linux-gnu/girepository-1.0')),
                       'GNOME_SHELL_DATADIR': str(sysroot / 'usr/share/gnome-shell'),
                       'GNOME_SHELL_LIBEXECDIR': str(sysroot / 'usr/libexec')}
        # Schema compilation is data-only and confined to this unique attempt.
        for folder in (Path('/usr/share/glib-2.0/schemas'), sysroot / 'usr/share/glib-2.0/schemas'):
            for source in folder.glob('*'):
                if source.suffix in ('.xml', '.override'):
                    (workspace / 'schemas' / source.name).write_bytes(source.read_bytes())
        command = ['/usr/bin/glib-compile-schemas', str(workspace / 'schemas')]
        compiled = subprocess.run(command, env=environment, capture_output=True, text=True, timeout=5)
        report['commands'].append({'command': command, 'exit': compiled.returncode, 'stdout': compiled.stdout, 'stderr': compiled.stderr})
        compiled.check_returncode()
        report['schema_inputs'] = inventory(workspace / 'schemas')
        (workspace / 'bus.xml').write_text('<busconfig><type>session</type><listen>' + bus + '</listen>'
                                         '<policy context="default"><allow send_destination="*"/><allow receive_sender="*"/><allow own="*"/></policy></busconfig>')
        def launch(name, command):
            stream = (workspace / (name + '.log')).open('xb')
            streams.append(stream)
            process = subprocess.Popen(command, cwd=workspace, env=environment, stdin=subprocess.DEVNULL,
                                       stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            children.append((name, process))
            report['commands'].append({'command': command, 'pid': process.pid})
            return process
        launch('bus', ['/usr/bin/dbus-daemon', '--nofork', '--nopidfile', '--nosyslog', '--config-file=' + str(workspace / 'bus.xml')])
        # Explicit same-address call; this cannot discover or activate a user bus.
        for _ in range(20):
            ready = subprocess.run(['/usr/bin/gdbus', 'call', '--address', bus, '--dest', 'org.freedesktop.DBus',
                                    '--object-path', '/org/freedesktop/DBus', '--method', 'org.freedesktop.DBus.ListNames'],
                                   env=environment, capture_output=True, timeout=1)
            if ready.returncode == 0:
                break
            time.sleep(.05)
        else:
            raise TimeoutError('owned session bus unavailable')
        shell = launch('shell', [str(sysroot / 'usr/bin/gnome-shell'), '--x11', '--mode=user'])
        context = mp.get_context('spawn')
        local, remote = context.Pipe(duplex=False)
        worker = context.Process(target=observe, args=(environment, shell.pid, remote))
        worker.start()
        remote.close()
        while time.monotonic() - started < 40:
            if any(Path(stream.name).stat().st_size > 1024**2 for stream in streams):
                raise ValueError('laboratory log capacity exceeded')
            if local.poll(.05):
                report['observation'] = local.recv()
                if report['observation']['outcome'] != 'pass':
                    raise RuntimeError(report['observation']['error'])
                if shell.poll() is not None:
                    raise RuntimeError('shell exited during observation')
                report['mapped_files'] = mapped_files(shell.pid)
                report['outcome'] = 'pass'
                break
            if shell.poll() is not None:
                raise RuntimeError('shell exited during bootstrap: ' + str(shell.returncode))
            if not worker.is_alive():
                raise RuntimeError('observer exited without a report')
        else:
            raise TimeoutError('bounded GNOME bootstrap deadline')
    except Exception as error:
        report['error'] = type(error).__name__ + ': ' + str(error)
    finally:
        if worker:
            if worker.is_alive():
                worker.terminate()
            worker.join(2)
            if worker.is_alive():
                worker.kill()
                worker.join(2)
            report['cleanup'].append({'process': 'observer', 'pid': worker.pid, 'exit': worker.exitcode})
        for name, process in reversed(children):
            # Each retained child owns a fresh session/group; never signal a user group.
            before = group_members(process.pid)
            if before:
                os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=2)
            deadline = time.monotonic() + 2
            while time.monotonic() < deadline:
                try:
                    while os.waitpid(-process.pid, os.WNOHANG)[0]:
                        pass
                except ChildProcessError:
                    pass
                remaining = group_members(process.pid)
                if not remaining:
                    break
                os.killpg(process.pid, signal.SIGKILL)
                time.sleep(.02)
            else:
                report['outcome'] = 'fail'
                report['error'] = 'owned process group did not stop'
            report['cleanup'].append({'process': name, 'pid': process.pid, 'exit': process.returncode,
                                      'members_before_stop': before, 'members_after_stop': remaining})
        for stream in streams:
            stream.close()
        report['logs'] = {p.name: p.read_text(errors='replace')[:1048576] for p in workspace.glob('*.log')}
        if server:
            if server.poll() is None:
                server.terminate()
            try:
                stdout, stderr = server.communicate(timeout=2)
            except subprocess.TimeoutExpired:
                server.kill()
                stdout, stderr = server.communicate(timeout=2)
            report['cleanup'].append({'process': 'Xvfb', 'pid': server.pid, 'exit': server.returncode})
            report['logs']['Xvfb'] = (stdout + stderr).decode(errors='replace')[:1048576]
        report['elapsed_ms'] = round((time.monotonic() - started) * 1000)
        report['finished_at'] = datetime.now(timezone.utc).isoformat()
        path = evidence / (token + '.json')
        path.write_text(json.dumps(report, indent=2) + '\n')
        print(path)
        print(report['outcome'], report.get('error', 'owned shell bootstrap observed'))
    return 0 if report['outcome'] == 'pass' else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('build_dir', type=Path)
    args = parser.parse_args()
    sys.exit(run(owned_build(args.build_dir)))
