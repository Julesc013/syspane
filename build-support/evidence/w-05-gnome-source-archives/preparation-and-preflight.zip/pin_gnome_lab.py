import apt, apt_pkg, json, urllib.parse, sys
from pathlib import Path
apt_pkg.config.set('APT::Install-Recommends', 'false')
if len(sys.argv) > 1:
    apt_pkg.config.set('Dir::State::lists', sys.argv[1])
cache = apt.Cache()
for name in ('gnome-shell', 'gnome-shell-extension-desktop-icons-ng'):
    cache[name].mark_install()
rows = []
for package in sorted(cache.get_changes(), key=lambda x: x.name):
    version = package.candidate
    rows.append({'package': package.name, 'version': version.version,
                 'filename': Path(urllib.parse.unquote(urllib.parse.urlparse(version.uri).path)).name,
                 'url': version.uri.replace('http://', 'https://', 1),
                 'bytes': version.size, 'installed_bytes': version.installed_size,
                 'sha256': version.sha256})
value = {'version': '0.1.0', 'profile': 'Ubuntu 24.04 amd64 GNOME 46, extraction only',
         'resolution': 'Installed host plus missing/upgraded dependencies; APT recommends disabled. Owned refreshed signed Ubuntu metadata; no installation admitted.',
         'roots': ['gnome-shell', 'gnome-shell-extension-desktop-icons-ng'], 'packages': rows}
Path('build-support/gnome-lab-packages.json').write_text(json.dumps(value, indent=2) + '\n')
print(len(rows), sum(x['bytes'] for x in rows), sum(x['installed_bytes'] for x in rows))
